<?php
// Configuración de la conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "motocicletas";

// Crear objeto PDO
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Configurar el modo de error para lanzar excepciones
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Conexión establecida correctamente";
} catch(PDOException $e) {
    echo "Error al conectar a la base de datos: " . $e->getMessage();
}

// Ejemplo de consulta SQL
$stmt = $conn->query("SELECT nombre, descripcion, trasmision, suspencionDelantera, suspencionTrasera, frenoDelanter, Freno, capacidadTanque FROM moto");
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($rows as $row) {
    echo "<h2>" . $row["nombre"] . "</h2>";
    echo "<p>" . $row["descripcion"] . "</p>";
    echo "<p>Trasmision: " . $row["trasmision"] . "</p>";
    echo "<p>Suspensión delantera: " . $row["suspencionDelantera"] . "</p>";
    echo "<p>Suspensión trasera: " . $row["suspencionTrasera"] . "</p>";
    echo "<p>Freno delantero: " . $row["frenoDelanter"] . "</p>";
    echo "<p>Freno trasero: " . $row["Freno"] . "</p>";
    echo "<p>Capacidad del tanque: " . $row["capacidadTanque"] . "</p>";
}
?>